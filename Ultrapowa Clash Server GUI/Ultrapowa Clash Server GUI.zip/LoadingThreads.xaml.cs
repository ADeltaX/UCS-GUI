﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UCS
{
    /// <summary>
    /// Logica di interazione per LoadingThreads.xaml
    /// </summary>
    public partial class LoadingThreads : Window
    {
        public LoadingThreads()
        {
            label.Content = "Loading " + Convert.ToString(int.Parse(ConfigurationManager.AppSettings["programThreadCount"])) + " threads";
            InitializeComponent();
        }
    }
}
